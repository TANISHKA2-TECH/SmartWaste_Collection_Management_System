import unittest

from smart_waste import core
from smart_waste.models import Bin


def make_bin(i, fill, lat=0.0, lon=0.0, threshold=None):
    return Bin(i, "bin%d" % i, lat, lon, "A", 100.0, fill, threshold)


class FillPercentTests(unittest.TestCase):
    def test_converts_distance(self):
        self.assertEqual(core.calc_fill_percent(20, 100), 80.0)

    def test_rejects_bad_values(self):
        self.assertIsNone(core.calc_fill_percent(120, 100))
        self.assertIsNone(core.calc_fill_percent(-1, 100))
        self.assertIsNone(core.calc_fill_percent(10, 0))

    def test_retry_logs_each_failure(self):
        values = iter([500, 500, 30])
        log = []
        self.assertEqual(core.read_with_retry(lambda: next(values), 100, 3, log), 70.0)
        self.assertEqual(len(log), 2)

    def test_retry_gives_up(self):
        log = []
        self.assertIsNone(core.read_with_retry(lambda: 999, 100, 3, log))
        self.assertEqual(len(log), 3)


class RouteLogicTests(unittest.TestCase):
    def test_threshold_rule(self):
        bins = [make_bin(1, 90), make_bin(2, 40), make_bin(3, 80)]
        self.assertEqual([b.bin_id for b in core.select_bins(bins, 80)], [1, 3])

    def test_per_bin_threshold_overrides_default(self):
        self.assertEqual([b.bin_id for b in core.select_bins([make_bin(1, 50, threshold=40)], 80)], [1])

    def test_nearest_neighbour_order(self):
        near, far = make_bin(1, 90, 0.001, 0), make_bin(2, 90, 0.010, 0)
        self.assertEqual([b.bin_id for b in core.nearest_neighbour_route((0, 0), [far, near])], [1, 2])

    def test_route_length_positive(self):
        self.assertGreater(core.route_length_km((0, 0), [make_bin(1, 90, 0.01, 0)]), 1.0)

    def test_edit_route(self):
        self.assertEqual(core.edit_route([1, 2], add=3, remove=1), [2, 3])
        self.assertEqual(core.edit_route([1, 2], add=2), [1, 2])

    def test_bin_state_colours(self):
        self.assertEqual(core.bin_state(30, 80), "green")
        self.assertEqual(core.bin_state(65, 80), "yellow")
        self.assertEqual(core.bin_state(80, 80), "red")


class PasswordTests(unittest.TestCase):
    def test_hash_and_verify(self):
        salt, digest = core.hash_password("secret")
        self.assertTrue(core.verify_password("secret", salt, digest))
        self.assertFalse(core.verify_password("wrong", salt, digest))


if __name__ == "__main__":
    unittest.main()
