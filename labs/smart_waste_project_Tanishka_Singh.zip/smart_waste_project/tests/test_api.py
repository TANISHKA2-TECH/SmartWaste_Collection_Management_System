import json
import threading
import unittest
import urllib.error
import urllib.request

from smart_waste.db import connect
from smart_waste.server import create_server
from smart_waste.services import App


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = App(connect())
        cls.app.seed_demo()
        cls.server = create_server(cls.app, "127.0.0.1", 0)
        cls.url = "http://127.0.0.1:%d" % cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()

    def call(self, method, path, body=None, token=None):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = "Bearer " + token
        req = urllib.request.Request(self.url + path, data=json.dumps(body).encode() if body is not None else None,
                                     headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.status, json.loads(resp.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read())

    def login(self, user, password):
        return self.call("POST", "/api/login", {"username": user, "password": password})[1]["token"]

    def test_dashboard_page_is_served(self):
        with urllib.request.urlopen(self.url + "/") as resp:
            self.assertIn(b"Smart Waste Collection", resp.read())

    def test_bins_are_public(self):
        status, bins = self.call("GET", "/api/bins")
        self.assertEqual(status, 200)
        self.assertEqual(len(bins), 10)

    def test_admin_endpoints_need_login(self):
        self.assertEqual(self.call("GET", "/api/alerts")[0], 401)
        driver = self.login("driver", "driver123")
        self.assertEqual(self.call("GET", "/api/alerts", token=driver)[0], 403)

    def test_full_flow(self):
        for i in (1, 2):
            status, r = self.call("POST", "/api/readings", {"bin_id": i, "distance_cm": 5})
            self.assertEqual(status, 201)
            self.assertTrue(r["valid"])
        admin = self.login("admin", "admin123")
        status, route = self.call("POST", "/api/routes", token=admin)
        self.assertEqual(status, 201)
        rid = route["route_id"]
        self.assertEqual(self.call("POST", "/api/routes/%d/publish" % rid, token=admin)[0], 200)
        status, tracking = self.call("POST", "/api/complaints", {"bin_id": 1, "description": "smells"})
        self.assertEqual(status, 201)
        driver = self.login("driver", "driver123")
        status, r = self.call("POST", "/api/bins/1/collected", token=driver)
        self.assertEqual(r["complaints_resolved"], 1)
        status, c = self.call("GET", "/api/complaints/" + tracking["tracking_id"])
        self.assertEqual(c["status"], "Resolved")

    def test_bad_requests(self):
        self.assertEqual(self.call("POST", "/api/readings", {})[0], 400)
        self.assertEqual(self.call("POST", "/api/complaints", {"bin_id": 1, "description": ""})[0], 400)
        self.assertEqual(self.call("GET", "/api/nothing")[0], 404)


if __name__ == "__main__":
    unittest.main()


class SimulatorTests(unittest.TestCase):
    def test_simulator_sends_readings_and_raises_alerts(self):
        from smart_waste import simulator
        app = App(connect())
        app.seed_demo()
        server = create_server(app, "127.0.0.1", 0)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        try:
            url = "http://127.0.0.1:%d" % server.server_address[1]
            summary = simulator.run(url, ticks=6, delay=0, fail_rate=0.3, seed=3)
        finally:
            server.shutdown()
            server.server_close()
        self.assertGreater(summary["sent"], 30)
        self.assertGreater(summary["retries"], 0)
        self.assertGreater(len(app.alerts.list()), 0)
