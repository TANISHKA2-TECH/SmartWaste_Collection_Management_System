import unittest

from smart_waste.db import connect
from smart_waste.services import App, AuthError, Forbidden, NotFound, ValidationError


def new_app():
    app = App(connect())
    app.seed_demo()
    return app


class MonitoringAndAlertTests(unittest.TestCase):
    def setUp(self):
        self.app = new_app()

    def test_reading_updates_bin(self):
        r = self.app.ingestion.record(1, distance_cm=40)
        self.assertTrue(r["valid"])
        self.assertEqual(self.app.bins.get(1)["fill_level"], 60.0)

    def test_invalid_reading_is_logged_not_used(self):
        r = self.app.ingestion.record(1, distance_cm=500)
        self.assertFalse(r["valid"])
        self.assertEqual(self.app.bins.get(1)["fill_level"], 0)
        self.assertEqual(self.app.conn.execute("SELECT COUNT(*) c FROM readings WHERE valid=0").fetchone()["c"], 1)

    def test_alert_when_threshold_crossed(self):
        self.app.ingestion.record(1, fill_level=85)
        self.assertEqual(len(self.app.alerts.list()), 1)
        self.assertEqual(self.app.notifier.sent[0]["audience"], "admin,driver")

    def test_no_duplicate_open_alert(self):
        self.app.ingestion.record(1, fill_level=85)
        self.app.ingestion.record(1, fill_level=90)
        self.assertEqual(len(self.app.alerts.list()), 1)

    def test_no_alert_below_threshold(self):
        self.app.ingestion.record(1, fill_level=50)
        self.assertEqual(self.app.alerts.list(), [])

    def test_threshold_can_be_changed_per_bin(self):
        self.app.alerts.set_threshold(40, bin_id=1)
        self.app.ingestion.record(1, fill_level=50)
        self.assertEqual(len(self.app.alerts.list()), 1)

    def test_threshold_validation(self):
        with self.assertRaises(ValidationError):
            self.app.alerts.set_threshold(150)

    def test_unknown_bin(self):
        with self.assertRaises(NotFound):
            self.app.ingestion.record(999, fill_level=10)


class RouteAndCollectionTests(unittest.TestCase):
    def setUp(self):
        self.app = new_app()
        for i, fill in ((1, 90), (2, 85), (3, 30)):
            self.app.ingestion.record(i, fill_level=fill)

    def test_route_contains_only_bins_at_threshold(self):
        route = self.app.routes.generate()
        self.assertEqual(sorted(s["bin_id"] for s in route["stops"]), [1, 2])
        self.assertGreater(route["total_km"], 0)

    def test_route_needs_a_full_bin(self):
        app = new_app()
        with self.assertRaises(ValidationError):
            app.routes.generate()

    def test_admin_can_add_and_remove_bins(self):
        rid = self.app.routes.generate()["route_id"]
        edited = self.app.routes.edit(rid, add=3, remove=1)
        self.assertEqual(sorted(s["bin_id"] for s in edited["stops"]), [2, 3])

    def test_collection_resets_bin_and_completes_route(self):
        route = self.app.routes.generate()
        rid = route["route_id"]
        self.app.routes.publish(rid)
        self.app.routes.mark_collected(1)
        self.assertEqual(self.app.routes.get(rid)["status"], "In Progress")
        self.app.routes.mark_collected(2)
        self.assertEqual(self.app.routes.get(rid)["status"], "Completed")
        self.assertEqual(self.app.bins.get(1)["fill_level"], 0)
        self.assertEqual(self.app.alerts.list()[0]["status"], "Closed")

    def test_collection_resolves_complaints(self):
        tracking = self.app.complaints.submit(1, "overflowing")
        self.assertEqual(self.app.complaints.status(tracking)["status"], "Pending")
        self.app.routes.mark_collected(1)
        self.assertEqual(self.app.complaints.status(tracking)["status"], "Resolved")

    def test_report_counts_collections(self):
        self.app.routes.mark_collected(1)
        today = self.app.conn.execute("SELECT date('now') d").fetchone()["d"]
        report = self.app.analytics.report("2000-01-01", "2999-12-31")
        self.assertEqual(report["total_collections"], 1)
        self.assertIsNotNone(today)


class ComplaintAndAuthTests(unittest.TestCase):
    def setUp(self):
        self.app = new_app()

    def test_tracking_ids_are_unique(self):
        a = self.app.complaints.submit(1, "one")
        b = self.app.complaints.submit(1, "two")
        self.assertNotEqual(a, b)

    def test_complaint_needs_description(self):
        with self.assertRaises(ValidationError):
            self.app.complaints.submit(1, "   ")

    def test_unknown_tracking_id(self):
        with self.assertRaises(NotFound):
            self.app.complaints.status("CMP-999999")

    def test_login_and_roles(self):
        token = self.app.auth.login("admin", "admin123")["token"]
        self.assertEqual(self.app.auth.require(token, "admin").username, "admin")
        driver = self.app.auth.login("driver", "driver123")["token"]
        with self.assertRaises(Forbidden):
            self.app.auth.require(driver, "admin")

    def test_wrong_password(self):
        with self.assertRaises(AuthError):
            self.app.auth.login("admin", "nope")

    def test_login_required(self):
        with self.assertRaises(AuthError):
            self.app.auth.require("", "admin")


if __name__ == "__main__":
    unittest.main()
