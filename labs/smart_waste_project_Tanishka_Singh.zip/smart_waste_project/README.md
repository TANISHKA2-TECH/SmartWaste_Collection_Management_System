# Smart Waste Collection Management System - working prototype

Prototype of the system described in the SRS (v1.0) and modelled in Labs 3 to 9.
It uses only the Python standard library (Python 3.9+), so nothing needs to be installed.

![Dashboard](docs/dashboard.png)

## What it does

| SRS feature | Where it is implemented |
|---|---|
| Bin fill-level monitoring (REQ-BM) | `core.calc_fill_percent`, `core.read_with_retry`, `IngestionService`, `simulator.py` |
| Threshold alert and notification (REQ-AL) | `AlertService`, `LogNotifier` (stands in for FCM) |
| Route optimization (REQ-RO) | `core.nearest_neighbour_route`, `RouteService` (generate, add / remove bin, publish) |
| Admin dashboard and analytics (REQ-DB) | `static/index.html`, `AnalyticsService`, `AuthService` |
| Citizen complaints (REQ-CF) | `ComplaintService`, complaint form on the dashboard |
| Business rules (SRS 5.5) | `core.select_bins`, `RouteService.mark_collected` (resolves complaints) |

Class names follow the Lab 3 class diagram (`models.py`), and the services follow the backend modules of the Lab 9 component diagram.

## Run it

```bash
python -m smart_waste.server --port 8000          # starts API + dashboard, creates smart_waste.db
python -m smart_waste.simulator --ticks 10        # in a second terminal: fake sensor nodes send readings
```

Open http://127.0.0.1:8000. Demo accounts: `admin / admin123` and `driver / driver123`.
Citizens need no login and can use the complaint form.

Suggested demo: start the server, run the simulator, log in as admin, press *Generate optimized route*,
*Publish to driver*, then log in as driver and press *Mark collected*.

## Tests

```bash
python -m unittest discover -s tests -t .
```

## REST API (JSON)

| Method and path | Who | Purpose |
|---|---|---|
| `POST /api/readings` | sensor | `{bin_id, distance_cm}` or `{bin_id, fill_level}` |
| `GET /api/bins` | public | bins with fill-level and colour |
| `POST /api/login` | public | returns a bearer token |
| `POST /api/complaints`, `GET /api/complaints/<id>` | public | submit and track a complaint |
| `POST /api/thresholds` | admin | global or per-bin alert threshold |
| `POST /api/routes`, `GET /api/routes/latest` | admin | generate / view route |
| `POST /api/routes/<id>/bins`, `POST /api/routes/<id>/publish` | admin | add / remove bin, send to driver |
| `GET /api/alerts`, `GET /api/complaints`, `GET /api/report?from=&to=` | admin | alerts, complaints, analytics |
| `GET /api/driver/route`, `POST /api/bins/<id>/collected` | driver | view route, mark a bin collected |

## Limitations (prototype)

* SQLite instead of MongoDB / PostgreSQL, and plain HTTP instead of HTTPS / TLS.
* Distances use the haversine formula, not a mapping API (SRS TBD-2); the algorithm is nearest-neighbour (TBD-1).
* `LogNotifier` only records notifications; a real FCM adapter would replace it.
* The sensor endpoint has no authentication, there is no OTP login, and sample bins and passwords are demo data.
* Sensors are simulated; the ESP32 firmware is not included.

## Code metrics

```bash
python tools/measure_metrics.py     # size, cyclomatic complexity, maintainability, CK metrics, coverage -> metrics.json
```

Latest result: 37 tests passing, 91% line coverage, average cyclomatic complexity 2.1, maximum 7.
See the Lab 11 report for the full analysis.
