"""REST API (JSON over HTTP) and static dashboard, standard library only.

Run:  python -m smart_waste.server --port 8000
"""
import argparse
import json
import os
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import core
from .db import connect
from .services import App, AppError, NotFound, ValidationError, DEFAULT_THRESHOLD

STATIC = os.path.join(os.path.dirname(__file__), "static")
LOCK = threading.Lock()


def bin_view(app, row):
    b = app.bins.to_bin(row)
    threshold = b.effective_threshold(app.settings.get_threshold())
    return {"id": b.bin_id, "name": b.name, "lat": b.latitude, "lon": b.longitude, "zone": b.zone,
            "fill_level": b.fill_level, "threshold": threshold, "status": b.status,
            "color": core.bin_state(b.fill_level, threshold)}


def make_routes(app):
    """Return the routing table: (method, pattern, role, handler). role None means public."""

    def readings(ctx):
        d = ctx["body"]
        if "bin_id" not in d:
            raise ValidationError("bin_id is required")
        return 201, app.ingestion.record(int(d["bin_id"]), d.get("distance_cm"), d.get("fill_level"), d.get("timestamp"))

    def list_bins(ctx):
        return 200, [bin_view(app, r) for r in app.bins.all()]

    def login(ctx):
        d = ctx["body"]
        return 200, app.auth.login(d.get("username", ""), d.get("password", ""))

    def set_threshold(ctx):
        d = ctx["body"]
        app.alerts.set_threshold(float(d.get("percent", 0)), d.get("bin_id"))
        return 200, {"ok": True, "global_threshold": app.settings.get_threshold()}

    def gen_route(ctx):
        return 201, app.routes.generate()

    def edit_route(ctx):
        d = ctx["body"]
        return 200, app.routes.edit(int(ctx["args"][0]), d.get("add"), d.get("remove"))

    def publish_route(ctx):
        return 200, app.routes.publish(int(ctx["args"][0]))

    def latest_route(ctx):
        return 200, app.routes.latest()

    def driver_route(ctx):
        return 200, app.routes.latest(["Published", "In Progress"])

    def collected(ctx):
        return 200, app.routes.mark_collected(int(ctx["args"][0]))

    def submit_complaint(ctx):
        d = ctx["body"]
        tracking = app.complaints.submit(int(d.get("bin_id", 0)), d.get("description", ""), d.get("photo_url", ""), d.get("contact", ""))
        return 201, {"tracking_id": tracking, "status": "Pending"}

    def complaint_status(ctx):
        return 200, app.complaints.status(ctx["args"][0])

    def list_complaints(ctx):
        return 200, app.complaints.list()

    def list_alerts(ctx):
        return 200, app.alerts.list()

    def report(ctx):
        q = ctx["query"]
        if "from" not in q or "to" not in q:
            raise ValidationError("from and to dates are required")
        return 200, app.analytics.report(q["from"], q["to"])

    def settings(ctx):
        return 200, {"global_threshold": app.settings.get_threshold(), "default": DEFAULT_THRESHOLD}

    return [
        ("POST", r"/api/readings", None, readings),
        ("GET", r"/api/bins", None, list_bins),
        ("POST", r"/api/login", None, login),
        ("POST", r"/api/complaints", None, submit_complaint),
        ("GET", r"/api/complaints/(CMP-\d+)", None, complaint_status),
        ("GET", r"/api/complaints", ("admin",), list_complaints),
        ("GET", r"/api/alerts", ("admin",), list_alerts),
        ("GET", r"/api/settings", ("admin",), settings),
        ("POST", r"/api/thresholds", ("admin",), set_threshold),
        ("POST", r"/api/routes", ("admin",), gen_route),
        ("GET", r"/api/routes/latest", ("admin",), latest_route),
        ("POST", r"/api/routes/(\d+)/bins", ("admin",), edit_route),
        ("POST", r"/api/routes/(\d+)/publish", ("admin",), publish_route),
        ("GET", r"/api/driver/route", ("driver", "admin"), driver_route),
        ("POST", r"/api/bins/(\d+)/collected", ("driver", "admin"), collected),
        ("GET", r"/api/report", ("admin",), report),
    ]


def make_handler(app):
    table = [(m, re.compile("^" + p + "$"), roles, fn) for m, p, roles, fn in make_routes(app)]

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def _send(self, status, payload, ctype="application/json"):
            data = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _read_json(self):
            length = int(self.headers.get("Content-Length") or 0)
            return json.loads(self.rfile.read(length) or b"{}") if length else {}

        @staticmethod
        def _parse_query(qs):
            return dict(p.split("=", 1) for p in qs.split("&") if "=" in p)

        @staticmethod
        def _find_route(method, path):
            for m, pattern, roles, fn in table:
                match = pattern.match(path)
                if m == method and match:
                    return roles, fn, match
            return None

        def _call(self, roles, fn, ctx):
            with LOCK:
                if roles:
                    token = (self.headers.get("Authorization") or "").replace("Bearer ", "")
                    app.auth.require(token, *roles)
                return fn(ctx)

        def _dispatch(self, method):
            path, _, qs = self.path.partition("?")
            if method == "GET" and not path.startswith("/api/"):
                return self._static(path)
            try:
                body = self._read_json()
            except ValueError:
                return self._send(400, {"error": "invalid JSON"})
            found = self._find_route(method, path)
            if found is None:
                return self._send(404, {"error": "not found"})
            roles, fn, match = found
            ctx = {"body": body, "query": self._parse_query(qs), "args": match.groups()}
            try:
                status, payload = self._call(roles, fn, ctx)
            except AppError as e:
                return self._send(e.status, {"error": str(e)})
            except (TypeError, ValueError) as e:
                return self._send(400, {"error": "bad request: %s" % e})
            self._send(status, payload)

        def _static(self, path):
            name = "index.html" if path in ("/", "") else os.path.basename(path)
            full = os.path.join(STATIC, name)
            if not os.path.isfile(full):
                return self._send(404, {"error": "not found"})
            with open(full, "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

    return Handler


def create_server(app, host="127.0.0.1", port=8000):
    return ThreadingHTTPServer((host, port), make_handler(app))


def main():
    parser = argparse.ArgumentParser(description="Smart Waste Collection server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--db", default="smart_waste.db")
    args = parser.parse_args()
    app = App(connect(args.db))
    app.seed_demo()
    server = create_server(app, args.host, args.port)
    print("Dashboard: http://%s:%d   (admin / admin123, driver / driver123 - demo accounts)" % (args.host, args.port))
    server.serve_forever()


if __name__ == "__main__":
    main()
