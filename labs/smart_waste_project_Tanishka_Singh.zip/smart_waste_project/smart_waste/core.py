"""Pure logic: no database, no network. Easy to unit test."""
import hashlib
import hmac
import math
import os


def calc_fill_percent(distance_cm, capacity_cm):
    """Convert the ultrasonic distance (sensor to waste) to a fill percentage."""
    if capacity_cm <= 0 or distance_cm < 0 or distance_cm > capacity_cm:
        return None
    return round(100 * (capacity_cm - distance_cm) / capacity_cm, 1)


def read_with_retry(sensor, capacity_cm, max_retries=3, log=None):
    """REQ-BM-3: retry a failed reading and log every failure."""
    for attempt in range(max_retries):
        percent = calc_fill_percent(sensor(), capacity_cm)
        if percent is not None:
            return percent
        if log is not None:
            log.append("read error, attempt %d" % (attempt + 1))
    return None


def bin_state(fill, threshold):
    """Colour used on the dashboard map (SRS 3.1)."""
    if fill >= threshold:
        return "red"
    if fill >= threshold - 20:
        return "yellow"
    return "green"


def select_bins(bins, default_threshold):
    """Business rule 5.5: only bins at or above the threshold join a route."""
    return [b for b in bins if b.is_above_threshold(default_threshold)]


def haversine_km(a, b):
    lat1, lon1, lat2, lon2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(h))


def nearest_neighbour_route(depot, bins):
    """Nearest-neighbour heuristic (TBD-1). Returns the bins in visiting order."""
    route, current, pending = [], depot, list(bins)
    while pending:
        nxt = min(pending, key=lambda b: haversine_km(current, (b.latitude, b.longitude)))
        route.append(nxt)
        pending.remove(nxt)
        current = (nxt.latitude, nxt.longitude)
    return route


def route_length_km(depot, route):
    total, current = 0.0, depot
    for b in route:
        point = (b.latitude, b.longitude)
        total += haversine_km(current, point)
        current = point
    return round(total, 2)


def edit_route(bin_ids, add=None, remove=None):
    """REQ-RO-3: the administrator may add or remove a bin."""
    ids = list(bin_ids)
    if remove is not None and remove in ids:
        ids.remove(remove)
    if add is not None and add not in ids:
        ids.append(add)
    return ids


def hash_password(password, salt=None):
    salt = salt or os.urandom(16).hex()
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100000).hex()
    return salt, digest


def verify_password(password, salt, digest):
    return hmac.compare_digest(hash_password(password, salt)[1], digest)
