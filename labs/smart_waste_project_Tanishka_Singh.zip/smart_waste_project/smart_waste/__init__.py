"""Smart Waste Collection Management System - working prototype (standard library only)."""
__version__ = "1.0"
