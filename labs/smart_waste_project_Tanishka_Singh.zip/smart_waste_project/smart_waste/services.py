"""Service layer: one class per module of the Lab 9 backend component diagram."""
import secrets
from datetime import datetime, timedelta

from . import core
from .models import Administrator, Driver, User

DEFAULT_THRESHOLD = 80.0
DEPOT = (28.7525, 77.4985)          # sample depot position near the campus (demo data)
SESSION_HOURS = 8


class AppError(Exception):
    status = 400


class ValidationError(AppError):
    status = 400


class AuthError(AppError):
    status = 401


class Forbidden(AppError):
    status = 403


class NotFound(AppError):
    status = 404


def now():
    return datetime.now().replace(microsecond=0).isoformat()


class Settings:
    def __init__(self, conn):
        self.conn = conn

    def get_threshold(self):
        row = self.conn.execute("SELECT value FROM settings WHERE key='threshold'").fetchone()
        return float(row["value"]) if row else DEFAULT_THRESHOLD

    def set_global_threshold(self, percent):
        self.conn.execute("INSERT OR REPLACE INTO settings VALUES('threshold', ?)", (str(percent),))
        self.conn.commit()


class LogNotifier:
    """Notification adapter (FCM in the SRS). The prototype only records what would be sent."""

    def __init__(self):
        self.sent = []

    def send(self, audience, title, body):
        self.sent.append({"audience": audience, "title": title, "body": body})


class AuthService:
    def __init__(self, conn):
        self.conn = conn
        self.sessions = {}

    def create_user(self, username, password, role):
        salt, digest = core.hash_password(password)
        self.conn.execute("INSERT INTO users(username, salt, password_hash, role) VALUES(?,?,?,?)",
                          (username, salt, digest, role))
        self.conn.commit()

    def login(self, username, password):
        row = self.conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if row is None or not core.verify_password(password, row["salt"], row["password_hash"]):
            raise AuthError("invalid username or password")
        token = secrets.token_hex(16)
        self.sessions[token] = (self.to_user(row), datetime.now() + timedelta(hours=SESSION_HOURS))
        return {"token": token, "role": row["role"], "username": row["username"]}

    @staticmethod
    def to_user(row):
        if row["role"] == "admin":
            return Administrator(row["id"], row["username"])
        return Driver(row["id"], row["username"])

    def require(self, token, *roles):
        entry = self.sessions.get(token)
        if entry is None or entry[1] < datetime.now():
            raise AuthError("login required")
        user = entry[0]
        if roles and user.role not in roles:
            raise Forbidden("not allowed for role " + user.role)
        return user


class BinRepository:
    def __init__(self, conn):
        self.conn = conn

    def add(self, name, lat, lon, zone, capacity_cm=100.0):
        cur = self.conn.execute("INSERT INTO bins(name, latitude, longitude, zone, capacity_cm) VALUES(?,?,?,?,?)",
                                (name, lat, lon, zone, capacity_cm))
        self.conn.execute("INSERT INTO sensors(bin_id) VALUES(?)", (cur.lastrowid,))
        self.conn.commit()
        return cur.lastrowid

    def get(self, bin_id):
        row = self.conn.execute("SELECT * FROM bins WHERE id=?", (bin_id,)).fetchone()
        if row is None:
            raise NotFound("bin %s not found" % bin_id)
        return row

    def all(self):
        return self.conn.execute("SELECT * FROM bins ORDER BY id").fetchall()

    def to_bin(self, row):
        from .models import Bin
        return Bin(row["id"], row["name"], row["latitude"], row["longitude"], row["zone"],
                   row["capacity_cm"], row["fill_level"], row["threshold"], row["status"])


class AlertService:
    def __init__(self, conn, bins, settings, notifier):
        self.conn, self.bins, self.settings, self.notifier = conn, bins, settings, notifier

    def check(self, bin_id):
        """REQ-AL-2: create one alert when a bin crosses its threshold."""
        b = self.bins.to_bin(self.bins.get(bin_id))
        if not b.is_above_threshold(self.settings.get_threshold()):
            return None
        open_alert = self.conn.execute("SELECT id FROM alerts WHERE bin_id=? AND status='Open'", (bin_id,)).fetchone()
        if open_alert:
            return None
        message = "%s is %.0f%% full" % (b.name, b.fill_level)
        cur = self.conn.execute("INSERT INTO alerts(bin_id, ts, message, status) VALUES(?,?,?,?)",
                                (bin_id, now(), message, "Open"))
        self.conn.commit()
        self.notifier.send("admin,driver", "Bin needs collection", message)
        return cur.lastrowid

    def close_for_bin(self, bin_id):
        self.conn.execute("UPDATE alerts SET status='Closed' WHERE bin_id=? AND status='Open'", (bin_id,))
        self.conn.commit()

    def list(self):
        return [dict(r) for r in self.conn.execute("SELECT * FROM alerts ORDER BY id DESC").fetchall()]

    def set_threshold(self, percent, bin_id=None):
        """REQ-AL-1: per bin or global threshold."""
        if not 1 <= percent <= 100:
            raise ValidationError("threshold must be between 1 and 100")
        if bin_id is None:
            self.settings.set_global_threshold(percent)
        else:
            self.bins.get(bin_id)
            self.conn.execute("UPDATE bins SET threshold=? WHERE id=?", (percent, bin_id))
            self.conn.commit()


class IngestionService:
    def __init__(self, conn, bins, alerts, settings):
        self.conn, self.bins, self.alerts, self.settings = conn, bins, alerts, settings

    def record(self, bin_id, distance_cm=None, fill_level=None, ts=None):
        """REQ-BM-2: store a reading with bin id and timestamp; bad readings are logged, not used."""
        row = self.bins.get(bin_id)
        if fill_level is None and distance_cm is not None:
            fill_level = core.calc_fill_percent(float(distance_cm), row["capacity_cm"])
        valid = fill_level is not None and 0 <= float(fill_level) <= 100
        ts = ts or now()
        self.conn.execute("INSERT INTO readings(bin_id, fill_level, ts, valid) VALUES(?,?,?,?)",
                          (bin_id, fill_level if valid else None, ts, int(valid)))
        if not valid:
            self.conn.commit()
            return {"valid": False, "alert": None}
        self.conn.execute("UPDATE bins SET fill_level=?, status=? WHERE id=?",
                          (fill_level, self._status(row, float(fill_level)), bin_id))
        self.conn.commit()
        return {"valid": True, "fill_level": float(fill_level), "alert": self.alerts.check(bin_id)}

    def _status(self, row, fill):
        if row["status"] == "Scheduled":
            return "Scheduled"
        if fill >= 100:
            return "Overflowing"
        b = self.bins.to_bin(row)
        b.fill_level = fill
        return "Near Full" if b.is_above_threshold(self.settings.get_threshold()) else "Normal"


class ComplaintService:
    def __init__(self, conn, bins):
        self.conn, self.bins = conn, bins

    def submit(self, bin_id, description, photo_url="", contact=""):
        """REQ-CF-1 and REQ-CF-2: store the complaint and return a unique tracking id."""
        self.bins.get(bin_id)
        if not description or not description.strip():
            raise ValidationError("description is required")
        cur = self.conn.execute("INSERT INTO complaints(bin_id, description, photo_url, contact, created_at, status)"
                                " VALUES(?,?,?,?,?,?)", (bin_id, description.strip(), photo_url, contact, now(), "Pending"))
        self.conn.commit()
        return "CMP-%06d" % cur.lastrowid

    def status(self, tracking_id):
        """REQ-CF-3: Pending or Resolved."""
        try:
            number = int(tracking_id.split("-")[1])
        except (IndexError, ValueError):
            raise NotFound("unknown tracking id")
        row = self.conn.execute("SELECT * FROM complaints WHERE id=?", (number,)).fetchone()
        if row is None:
            raise NotFound("unknown tracking id")
        return {"tracking_id": tracking_id, "status": row["status"], "bin_id": row["bin_id"], "created_at": row["created_at"]}

    def list(self):
        return [dict(r, tracking_id="CMP-%06d" % r["id"]) for r in
                self.conn.execute("SELECT * FROM complaints ORDER BY id DESC").fetchall()]

    def resolve_for_bin(self, bin_id):
        """Business rule 5.5: a collected bin resolves its complaints."""
        cur = self.conn.execute("UPDATE complaints SET status='Resolved' WHERE bin_id=? AND status='Pending'", (bin_id,))
        self.conn.commit()
        return cur.rowcount


class RouteService:
    def __init__(self, conn, bins, settings, alerts, complaints, notifier):
        self.conn, self.bins, self.settings = conn, bins, settings
        self.alerts, self.complaints, self.notifier = alerts, complaints, notifier

    def generate(self, depot=DEPOT):
        """REQ-RO-1: route over all bins at or above the threshold."""
        chosen = core.select_bins([self.bins.to_bin(r) for r in self.bins.all()], self.settings.get_threshold())
        if not chosen:
            raise ValidationError("no bin needs collection")
        cur = self.conn.execute("INSERT INTO routes(route_date, total_km, status) VALUES(?,?,?)",
                                (now()[:10], 0, "Generated"))
        self._store(cur.lastrowid, chosen, depot)
        return self.get(cur.lastrowid)

    def _store(self, route_id, bin_models, depot):
        ordered = core.nearest_neighbour_route(depot, bin_models)
        self.conn.execute("DELETE FROM route_bins WHERE route_id=?", (route_id,))
        for seq, b in enumerate(ordered, start=1):
            self.conn.execute("INSERT INTO route_bins(route_id, bin_id, seq) VALUES(?,?,?)", (route_id, b.bin_id, seq))
            self.conn.execute("UPDATE bins SET status='Scheduled' WHERE id=?", (b.bin_id,))
        self.conn.execute("UPDATE routes SET total_km=? WHERE id=?", (core.route_length_km(depot, ordered), route_id))
        self.conn.commit()

    def get(self, route_id):
        r = self.conn.execute("SELECT * FROM routes WHERE id=?", (route_id,)).fetchone()
        if r is None:
            raise NotFound("route %s not found" % route_id)
        stops = self.conn.execute("SELECT rb.bin_id, rb.seq, rb.collected, b.name, b.latitude, b.longitude, b.fill_level"
                                  " FROM route_bins rb JOIN bins b ON b.id=rb.bin_id WHERE rb.route_id=? ORDER BY rb.seq",
                                  (route_id,)).fetchall()
        return {"route_id": r["id"], "route_date": r["route_date"], "total_km": r["total_km"],
                "status": r["status"], "stops": [dict(s) for s in stops]}

    def latest(self, statuses=None):
        sql = "SELECT id FROM routes"
        if statuses:
            sql += " WHERE status IN (%s)" % ",".join("?" * len(statuses))
        row = self.conn.execute(sql + " ORDER BY id DESC LIMIT 1", tuple(statuses or ())).fetchone()
        return self.get(row["id"]) if row else None

    def edit(self, route_id, add=None, remove=None, depot=DEPOT):
        """REQ-RO-3: add or remove a bin, then re-order the route."""
        route = self.get(route_id)
        current = [s["bin_id"] for s in route["stops"]]
        wanted = core.edit_route(current, add, remove)
        if add is not None:
            self.bins.get(add)
        if remove in current and remove not in wanted:
            self.conn.execute("UPDATE bins SET status='Near Full' WHERE id=?", (remove,))
        if not wanted:
            raise ValidationError("a route needs at least one bin")
        self._store(route_id, [self.bins.to_bin(self.bins.get(i)) for i in wanted], depot)
        return self.get(route_id)

    def publish(self, route_id):
        self.get(route_id)
        self.conn.execute("UPDATE routes SET status='Published' WHERE id=?", (route_id,))
        self.conn.commit()
        self.notifier.send("driver", "New route", "Route %d is ready" % route_id)
        return self.get(route_id)

    def mark_collected(self, bin_id):
        """Driver marks a bin collected: reset fill, close alert, resolve complaints, finish route."""
        row = self.bins.get(bin_id)
        self.conn.execute("INSERT INTO collections(bin_id, ts, fill_before) VALUES(?,?,?)", (bin_id, now(), row["fill_level"]))
        self.conn.execute("UPDATE bins SET fill_level=0, status='Collected' WHERE id=?", (bin_id,))
        self.conn.execute("UPDATE route_bins SET collected=1 WHERE bin_id=? AND collected=0", (bin_id,))
        self.conn.execute("UPDATE routes SET status='In Progress' WHERE status='Published' AND id IN"
                          " (SELECT route_id FROM route_bins WHERE bin_id=?)", (bin_id,))
        self.conn.execute("UPDATE routes SET status='Completed' WHERE status='In Progress' AND id NOT IN"
                          " (SELECT route_id FROM route_bins WHERE collected=0)")
        self.conn.commit()
        self.alerts.close_for_bin(bin_id)
        return {"bin_id": bin_id, "complaints_resolved": self.complaints.resolve_for_bin(bin_id)}


class AnalyticsService:
    def __init__(self, conn, bins):
        self.conn, self.bins = conn, bins

    def report(self, date_from, date_to):
        """REQ-DB-2: collections and average fill-level per bin for a date range."""
        start, end = date_from + "T00:00:00", date_to + "T23:59:59"
        rows = []
        for b in self.bins.all():
            collected = self.conn.execute("SELECT COUNT(*) c FROM collections WHERE bin_id=? AND ts BETWEEN ? AND ?",
                                          (b["id"], start, end)).fetchone()["c"]
            avg = self.conn.execute("SELECT AVG(fill_level) a FROM readings WHERE bin_id=? AND valid=1 AND ts BETWEEN ? AND ?",
                                    (b["id"], start, end)).fetchone()["a"]
            rows.append({"bin_id": b["id"], "name": b["name"], "collections": collected,
                         "avg_fill_level": None if avg is None else round(avg, 1)})
        return {"date_from": date_from, "date_to": date_to, "bins": rows,
                "total_collections": sum(r["collections"] for r in rows)}


class App:
    """Wires the services together (used by the HTTP server and by the tests)."""

    def __init__(self, conn, notifier=None):
        self.conn = conn
        self.notifier = notifier or LogNotifier()
        self.settings = Settings(conn)
        self.auth = AuthService(conn)
        self.bins = BinRepository(conn)
        self.alerts = AlertService(conn, self.bins, self.settings, self.notifier)
        self.ingestion = IngestionService(conn, self.bins, self.alerts, self.settings)
        self.complaints = ComplaintService(conn, self.bins)
        self.routes = RouteService(conn, self.bins, self.settings, self.alerts, self.complaints, self.notifier)
        self.analytics = AnalyticsService(conn, self.bins)

    def seed_demo(self):
        """Demo accounts and sample bins (change the passwords for any real use)."""
        if self.conn.execute("SELECT COUNT(*) c FROM users").fetchone()["c"] == 0:
            self.auth.create_user("admin", "admin123", "admin")
            self.auth.create_user("driver", "driver123", "driver")
        if self.conn.execute("SELECT COUNT(*) c FROM bins").fetchone()["c"] == 0:
            sample = [("Main Gate", 28.7531, 77.4979, "A"), ("Library", 28.7540, 77.4992, "A"), ("Canteen", 28.7519, 77.5004, "B"),
                      ("Hostel 1", 28.7508, 77.4968, "B"), ("Hostel 2", 28.7499, 77.4981, "B"), ("Sports Ground", 28.7550, 77.5010, "C"),
                      ("Admin Block", 28.7537, 77.5001, "A"), ("Parking", 28.7522, 77.4961, "C"), ("Lab Block", 28.7544, 77.4970, "A"),
                      ("Auditorium", 28.7515, 77.4990, "B")]
            for name, lat, lon, zone in sample:
                self.bins.add(name, lat, lon, zone)
