"""SQLite storage (MongoDB / PostgreSQL in the SRS; SQLite keeps the prototype dependency free)."""
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, salt TEXT, password_hash TEXT, role TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS bins(id INTEGER PRIMARY KEY, name TEXT, latitude REAL, longitude REAL, zone TEXT,
    capacity_cm REAL, fill_level REAL DEFAULT 0, threshold REAL, status TEXT DEFAULT 'Normal');
CREATE TABLE IF NOT EXISTS sensors(id INTEGER PRIMARY KEY, bin_id INTEGER, battery_level INTEGER DEFAULT 100,
    interval_min INTEGER DEFAULT 15, status TEXT DEFAULT 'Sleeping');
CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY, bin_id INTEGER, fill_level REAL, ts TEXT, valid INTEGER);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY, bin_id INTEGER, ts TEXT, message TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS routes(id INTEGER PRIMARY KEY, route_date TEXT, total_km REAL, status TEXT);
CREATE TABLE IF NOT EXISTS route_bins(route_id INTEGER, bin_id INTEGER, seq INTEGER, collected INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS collections(id INTEGER PRIMARY KEY, bin_id INTEGER, ts TEXT, fill_before REAL);
CREATE TABLE IF NOT EXISTS complaints(id INTEGER PRIMARY KEY, bin_id INTEGER, description TEXT, photo_url TEXT,
    contact TEXT, created_at TEXT, status TEXT);
"""


def connect(path=":memory:"):
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn
