"""Domain classes from the Lab 3 class diagram."""
from dataclasses import dataclass
from typing import Optional


@dataclass
class User:
    user_id: int
    username: str
    role: str = "user"


@dataclass
class Administrator(User):
    role: str = "admin"


@dataclass
class Driver(User):
    role: str = "driver"
    vehicle_id: str = ""


@dataclass
class Citizen:
    name: str = ""
    phone: str = ""


@dataclass
class Bin:
    bin_id: int
    name: str
    latitude: float
    longitude: float
    zone: str
    capacity_cm: float
    fill_level: float = 0.0
    threshold: Optional[float] = None
    status: str = "Normal"

    def effective_threshold(self, default):
        return default if self.threshold is None else self.threshold

    def is_above_threshold(self, default):
        return self.fill_level >= self.effective_threshold(default)


@dataclass
class SensorNode:
    sensor_id: int
    bin_id: int
    battery_level: int = 100
    interval_min: int = 15
    status: str = "Sleeping"


@dataclass
class SensorReading:
    reading_id: int
    bin_id: int
    fill_level: float
    timestamp: str
    is_valid: bool = True


@dataclass
class Alert:
    alert_id: int
    bin_id: int
    timestamp: str
    message: str
    status: str = "Open"


@dataclass
class Route:
    route_id: int
    route_date: str
    total_distance_km: float
    status: str = "Generated"


@dataclass
class Complaint:
    tracking_id: str
    bin_id: int
    description: str
    created_at: str
    photo_url: str = ""
    status: str = "Pending"


@dataclass
class Report:
    date_from: str
    date_to: str
    total_collections: int
    avg_fill_level: float
