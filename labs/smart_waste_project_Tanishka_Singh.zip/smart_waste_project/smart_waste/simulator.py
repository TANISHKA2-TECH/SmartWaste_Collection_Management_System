"""Sensor node simulator: behaves like the ESP32 firmware and posts readings to the server.

Run:  python -m smart_waste.simulator --url http://127.0.0.1:8000 --ticks 10 --delay 1
"""
import argparse
import json
import random
import time
import urllib.request

from . import core


def call(url, path, payload=None):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url + path, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


def make_sensor(true_fill, capacity, fail_rate):
    """Ultrasonic sensor model: distance from sensor to waste surface, sometimes a bad echo."""
    def read():
        if random.random() < fail_rate:
            return capacity + 50
        return capacity * (1 - true_fill[0] / 100) + random.uniform(-0.5, 0.5)
    return read


def run(url, ticks, delay, fail_rate=0.1, seed=None):
    random.seed(seed)
    bins = call(url, "/api/bins")
    state = {b["id"]: [random.uniform(10, 60)] for b in bins}
    summary = {"sent": 0, "retries": 0, "alerts": 0}
    for tick in range(ticks):
        for b in bins:
            state[b["id"]][0] = min(100.0, state[b["id"]][0] + random.uniform(2, 9))
            log = []
            sensor = make_sensor(state[b["id"]], 100.0, fail_rate)
            fill = core.read_with_retry(sensor, 100.0, 3, log)
            summary["retries"] += len(log)
            if fill is None:
                continue
            result = call(url, "/api/readings", {"bin_id": b["id"], "fill_level": fill})
            summary["sent"] += 1
            summary["alerts"] += 1 if result.get("alert") else 0
        time.sleep(delay)
    return summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://127.0.0.1:8000")
    ap.add_argument("--ticks", type=int, default=10)
    ap.add_argument("--delay", type=float, default=1.0)
    args = ap.parse_args()
    print(run(args.url, args.ticks, args.delay))
