"""Measure size, complexity, OO metrics and line coverage of the smart_waste package.

Run from the project folder:  python tools/measure_metrics.py
Writes metrics.json next to this script's parent folder.
"""
import ast, io, json, keyword, math, os, sys, threading, tokenize, unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PKG = os.path.join(ROOT, "smart_waste")
FILES = ["models.py", "core.py", "db.py", "services.py", "server.py", "simulator.py"]
sys.path.insert(0, ROOT)
os.chdir(ROOT)


def exec_lines(path):
    lines = set()
    def walk(code):
        for _, _, ln in code.co_lines():
            if ln:
                lines.add(ln)
        for k in code.co_consts:
            if hasattr(k, "co_lines"):
                walk(k)
    walk(compile(open(path).read(), path, "exec"))
    return lines


def run_coverage():
    targets = {os.path.join(PKG, f): exec_lines(os.path.join(PKG, f)) for f in FILES}
    hit = {p: set() for p in targets}
    def tracer(frame, event, arg):
        p = frame.f_code.co_filename
        if p in hit:
            if event == "line":
                hit[p].add(frame.f_lineno)
            return tracer
        return None
    threading.settrace(tracer)
    sys.settrace(tracer)
    result = unittest.TextTestRunner(stream=io.StringIO()).run(unittest.defaultTestLoader.discover("tests", top_level_dir=ROOT))
    sys.settrace(None)
    threading.settrace(None)
    cov = {os.path.basename(p): (len(l & hit[p]), len(l)) for p, l in targets.items()}
    return result, cov


def own_nodes(node):
    stack = list(ast.iter_child_nodes(node))
    while stack:
        x = stack.pop()
        yield x
        if not isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            stack.extend(ast.iter_child_nodes(x))


def cc(node):
    n = 1
    for x in own_nodes(node):
        if isinstance(x, (ast.If, ast.For, ast.While, ast.IfExp, ast.ExceptHandler, ast.Assert)):
            n += 1
        elif isinstance(x, ast.BoolOp):
            n += len(x.values) - 1
        elif isinstance(x, ast.comprehension):
            n += 1 + len(x.ifs)
    return n


def halstead(text):
    ops, opd = [], []
    for t in tokenize.generate_tokens(io.StringIO(text).readline):
        if t.type == tokenize.OP:
            ops.append(t.string)
        elif t.type == tokenize.NAME:
            (ops if keyword.iskeyword(t.string) else opd).append(t.string)
        elif t.type in (tokenize.NUMBER, tokenize.STRING):
            opd.append(t.string)
    n1, n2, N1, N2 = len(set(ops)), len(set(opd)), len(ops), len(opd)
    n, N = n1 + n2, N1 + N2
    V = N * math.log2(n)
    D = (n1 / 2) * (N2 / n2)
    return dict(n1=n1, n2=n2, N1=N1, N2=N2, n=n, N=N, V=V, D=D, E=D * V, T=D * V / 18, B=V / 3000)


def loc_of(text):
    return sum(1 for l in text.splitlines() if l.strip() and not l.strip().startswith("#"))


def analyse():
    trees, all_src = {}, ""
    for f in FILES:
        text = open(os.path.join(PKG, f)).read()
        all_src += text + "\n"
        trees[f] = (ast.parse(text), text)
    class_names = {n.name for t, _ in trees.values() for n in ast.walk(t) if isinstance(n, ast.ClassDef)}
    funcs, classes, imports = [], {}, {}
    for f, (tree, text) in trees.items():
        lines = text.splitlines()
        parent = {}
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                parent[child] = node
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                body = "\n".join(lines[node.lineno - 1:node.end_lineno])
                loc, c = loc_of(body), cc(node)
                V = max(halstead(body)["V"], 1)
                mi = max(0, (171 - 5.2 * math.log(V) - 0.23 * c - 16.2 * math.log(max(loc, 1))) * 100 / 171)
                owner = parent.get(node)
                funcs.append(dict(file=f, owner=owner.name if isinstance(owner, ast.ClassDef) else None,
                                  name=node.name, loc=loc, cc=c, V=V, MI=mi))
            if isinstance(node, ast.ClassDef):
                meths = [m for m in node.body if isinstance(m, ast.FunctionDef)]
                attrs = {}
                for m in meths:
                    attrs[m.name] = {x.attr for x in ast.walk(m) if isinstance(x, ast.Attribute)
                                     and isinstance(x.value, ast.Name) and x.value.id == "self"}
                names = [m.name for m in meths if m.name != "__init__"]
                P = Q = 0
                for i in range(len(names)):
                    for j in range(i + 1, len(names)):
                        Q, P = (Q + 1, P) if attrs[names[i]] & attrs[names[j]] else (Q, P + 1)
                refs = {x.id for x in ast.walk(node) if isinstance(x, ast.Name) and x.id in class_names and x.id != node.name}
                refs |= {x.attr for x in ast.walk(node) if isinstance(x, ast.Attribute) and x.attr in class_names and x.attr != node.name}
                classes[node.name] = dict(file=f, methods=len(meths), wmc=sum(cc(m) for m in meths), cbo=len(refs),
                                          lcom=max(P - Q, 0), bases=[b.id for b in node.bases if isinstance(b, ast.Name)])
        imports[f] = sorted({n.module.split(".")[-1] if n.module else x.name for n in ast.walk(tree)
                             if isinstance(n, ast.ImportFrom) and n.level == 1 for x in n.names
                             for n in [n]} | set())
    def dit(name):
        b = [x for x in classes.get(name, {}).get("bases", []) if x in classes]
        return 0 if not b else 1 + max(dit(x) for x in b)
    for k, v in classes.items():
        v["dit"] = dit(k)
        v["noc"] = sum(1 for o in classes.values() if k in o["bases"])
    return funcs, classes, all_src, trees


def module_coupling():
    """Afferent / efferent coupling between the package modules (from relative imports)."""
    deps = {}
    for f in FILES:
        tree = ast.parse(open(os.path.join(PKG, f)).read())
        mods = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom) and n.level == 1:
                if n.module:
                    mods.add(n.module)
                else:
                    mods.update(a.name for a in n.names)
        deps[f[:-3]] = mods & {x[:-3] for x in FILES}
    rows = {}
    for m in deps:
        ce = len(deps[m])
        ca = sum(1 for o in deps if m in deps[o])
        rows[m] = dict(ca=ca, ce=ce, inst=(ce / (ca + ce)) if ca + ce else 0.0)
    return rows


def main():
    result, cov = run_coverage()
    funcs, classes, all_src, trees = analyse()
    test_files = [f for f in os.listdir("tests") if f.startswith("test_")]
    out = dict(
        funcs=funcs, classes=classes, module=halstead(all_src), coupling=module_coupling(),
        src_loc={f: loc_of(trees[f][1]) for f in FILES},
        test_loc=sum(loc_of(open("tests/" + f).read()) for f in test_files),
        html_loc=loc_of(open(os.path.join(PKG, "static", "index.html")).read()),
        ntests=result.testsRun, failures=len(result.failures) + len(result.errors), cov=cov,
        cov_pct=100 * sum(a for a, b in cov.values()) / sum(b for a, b in cov.values()))
    json.dump(out, open(os.path.join(ROOT, "metrics.json"), "w"), indent=1)
    print("tests %d, failures %d, line coverage %.1f%%" % (out["ntests"], out["failures"], out["cov_pct"]))
    print("functions %d, average complexity %.2f, maximum %d" % (len(funcs), sum(f["cc"] for f in funcs) / len(funcs), max(f["cc"] for f in funcs)))


if __name__ == "__main__":
    main()
